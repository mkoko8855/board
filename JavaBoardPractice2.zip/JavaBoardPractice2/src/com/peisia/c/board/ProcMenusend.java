package com.peisia.c.board;

import com.peisia.c.board.data.Data;
import com.peisia.c.board.data.Post;
import com.peisia.util.Ci;
import com.peisia.util.Cw;

public class ProcMenusend {
	static void run() {
		Cw.wn("원고보내기");
		String cmd = Ci.r("보낼 글 리스트");
		
		for (Post p : Data.posts) {
			if (cmd.equals(p.instanceNo + "")) {
				
				for (Post h : Data.posts) {
					if (cmd.equals(h.instancehit + "")) {
					}

					String content = Ci.rl("보낼 글 내용");
					p.content = content;
					Cw.wn("보내기 완료");
				}
			}
		}
	}
}
