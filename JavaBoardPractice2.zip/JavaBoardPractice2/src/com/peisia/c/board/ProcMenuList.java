package com.peisia.c.board;

import com.peisia.c.board.data.Data;
import com.peisia.c.board.data.Post;
import com.peisia.util.Cw;

public class ProcMenuList {
	static void run() {
		
		Cw.wn("리스트");
		for(int i=0; i<Data.posts.size(); i++){
			Data.posts.get(i).infoForList();
		
		}
	}
}



