package com.peisia.c.board.data;

import java.util.ArrayList;

public class Data {
	
	static public ArrayList<Post> posts = new ArrayList<Post>(); 
	
	
	
	
	static public void loadData() {
	}
}
