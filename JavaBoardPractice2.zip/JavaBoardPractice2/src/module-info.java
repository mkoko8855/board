/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module JavaBoardPractice2 {
}